import Hero from "./components/home/Hero";
import LatestSaloons from "./components/saloons/latestSaloons";
import Services from "./components/home/Services";
import { supabase } from "./lib/supabaseClient";
import { Salon } from "./lib/types";
import Pastwork from "./components/home/Pastwork";
import Testimonials from "./components/home/Testimonials";
import RevealWrapper from "./components/general/RevealWrapper";

export default async function Home() {
  let salons: Salon[] = [];

  try {


    const { data, error } = await supabase
      .from("salons")
      .select(`
    id,
    name,
    slug,  
    services (
      id,
      name,
      price,
      duration
    )
  `);
    if (error) {
      console.log(error.message);
      return;
    }
    salons = (data ?? []) as Salon[];

    console.log("Salons Data:");
    // console.log(JSON.stringify(data, null, 2));

  } catch (error: unknown) {
    console.log(
      "Supabase Error:",
      error instanceof Error
        ? error.message
        : "Something went wrong"
    );
  }


  return (
    <>

  <RevealWrapper>
  <Hero />
</RevealWrapper>

<RevealWrapper className="reveal-up" delay={200}>
  <Services />
</RevealWrapper>

<RevealWrapper className="reveal-right" delay={300}>
  <Pastwork />
</RevealWrapper>

<RevealWrapper className="reveal-left" delay={300}>
  <Testimonials />
</RevealWrapper>
      <div className="min-h-screen p-8">

        <h1 className="text-sm font-bold text-secondary">

          Project coming soon ------  Natural Beauty
        </h1>
        <LatestSaloons salons={salons} />
        {/* <pre className="mt-10">
        {JSON.stringify(salons, null, 2)}
      </pre> */}

      </div>
    </>
  );
}