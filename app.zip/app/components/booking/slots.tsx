"use client";

import { formatTime, supabase } from "@/app/lib/supabaseClient";
import { availabilityType, slotsType } from "@/app/lib/types";
import React, { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  Clock3,
  Sunrise,
  Sun,
  Sunset,
  CircleCheck,
  CircleX,
  AlertCircle,
  ChevronRight,
} from "lucide-react";

function Slots({ slots }: { slots: availabilityType }) {
  const [timeSlots, setTimeSlots] = useState<slotsType[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("Morning");

  useEffect(() => {
    if (!slots) return;

    async function getServiceTimeSlots() {
      try {
        setLoading(true);
        const { data, error } = await supabase.rpc(
          "get_available_slots",
          {
            p_booking_date: slots.booking_date,
            p_salon_id: slots.salon_id,
            p_service_id: slots.service_id,
            p_open_time: slots.open_time,
            p_close_time: slots.close_time,
            p_slot_duration: 30,
            p_max_slots: 3,
          }
        );

        if (error) throw error;
        setTimeSlots(data || []);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    }

    getServiceTimeSlots();
  }, [slots]);

  const filteredSlots = useMemo(() => {
    return timeSlots.filter(
      (slot) => slot.time_period === selectedPeriod
    );
  }, [timeSlots, selectedPeriod]);

  const periodCounts = {
    Morning: timeSlots.filter((x) => x.time_period === "Morning").length,
    Noon: timeSlots.filter((x) => x.time_period === "Noon").length,
    Evening: timeSlots.filter((x) => x.time_period === "Evening").length,
  };

  const periods = [
    { id: "Morning", icon: Sunrise },
    { id: "Noon", icon: Sun },
    { id: "Evening", icon: Sunset },
  ];

  if (slots.is_closed) {
    return (
      <div className="flex h-screen justify-center items-center">
        <div className="text-center">
          <CircleX className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-semibold text-gray-700">Salon Closed</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-120px)] max-w-6xl mx-auto py-3 gap-3">
      {/* Left Sidebar - Time Periods */}
      <div className="w-56 flex-shrink-0 bg-white rounded-lg border border-gray-100 overflow-hidden">
        <div className="p-3 border-b border-gray-100">
          <h3 className="text-lg font-medium text-primary flex items-center gap-2">
            <Clock3 className="w-4 h-4 text-primary" />
            Time Slots
          </h3>
        </div>
        
        <div className="p-2 space-y-1">
          {periods.map((period) => {
            const isSelected = selectedPeriod === period.id;
            const Icon = period.icon;
            const count = periodCounts[period.id as keyof typeof periodCounts];

            return (
              <button
                key={period.id}
                onClick={() => setSelectedPeriod(period.id)}
                className={`
                  w-full flex items-center gap-2 px-3 py-2 rounded-md transition-all text-sm
                  ${
                    isSelected
                      ? "bg-secondary/30 text-se "
                      : "hover:bg-gray-50 text-gray-600 "
                  }
                `}
              >
                <Icon
                  className={`w-4 h-4 ${
                    isSelected ? "text-primary" : "text-secondary"
                  }`}
                />
                <span className="flex-1 text-left font-medium">
                  {period.id}
                </span>
                <span
                  className={`
                    px-1.5 py-0.5 rounded-full text-xs
                    ${
                      isSelected
                        ? "bg-primary text-white"
                        : "bg-gray-100 text-gray-500"
                    }
                  `}
                >
                  {count}
                </span>
                {isSelected && (
                  <ChevronRight className="w-3 h-3 text-primary" />
                )}
              </button>
            );
          })}
        </div>

        {/* Summary at bottom of sidebar */}
        <div className="p-3 border-t border-gray-100 mt-auto">
          <div className="text-sm text-primary space-y-0.5">
            <p>Total: <span className="font-medium text-primary">{timeSlots.length}</span></p>
            <p>Available: <span className="font-medium text-primary">
              {timeSlots.filter(x => x.slot_status === "Available").length}
            </span></p>
          </div>
        </div>
      </div>

      {/* Right Content - Slots Grid */}
      <div className="flex-1 bg-white rounded-lg border border-gray-100 overflow-hidden">
        {loading && (
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"></div>
          </div>
        )}

        {!loading && (
          <div className="h-full flex flex-col">
            {/* Header */}
            <div className="px-4 py-2.5 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-gray-700">
                  {selectedPeriod}
                </h3>
                <p className="text-sm text-gray-400">
                  {filteredSlots.length} slots
                </p>
              </div>
              {timeSlots[0] && (
                <div className="text-sm text-gray-400">
                  <span className="flex items-center gap-1">
                    <CalendarDays className="w-3.5 h-3.5" />
                    {timeSlots[0]?.avb_date || "Date"}
                  </span>
                </div>
              )}
            </div>

            {/* Slots Grid - 2 columns */}
            <div className="flex-1 overflow-y-auto p-3">
              <div className="grid grid-cols-2 gap-2">
                {filteredSlots.length > 0 ? (
                  filteredSlots.map((slot: slotsType, index: number) => {
                    const isAvailable = slot.slot_status === "Available";
                    const isFull = slot.slot_status === "Full";
                    const isPending = slot.slot_status === "Pending";

                    return (
                      <button
                        key={index}
                        disabled={!isAvailable}
                        className={`
                          relative bg-white border rounded-md p-3 text-left transition-all
                          ${
                            isAvailable
                              ? "border-gray-200 hover:border-primary/50 hover:bg-primary/5 cursor-pointer"
                              : isFull
                              ? "border-gray-100 bg-gray-50/50 cursor-not-allowed opacity-60"
                              : "border-gray-100 bg-gray-50/50 cursor-not-allowed opacity-60"
                          }
                        `}
                      >
                        {/* Status Indicator */}
                        <div className="absolute top-1.5 right-1.5">
                          {isAvailable ? (
                            <CircleCheck className="w-3.5 h-3.5 text-primary" />
                          ) : isFull ? (
                            <CircleX className="w-3.5 h-3.5 text-gray-400" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5 text-gray-400" />
                          )}
                        </div>

                        {/* Time */}
                        <div className="flex items-center gap-1.5">
                          <Clock3
                            className={`w-3 h-3 ${
                              isAvailable ? "text-primary" : "text-gray-400"
                            }`}
                          />
                          <span className="text-sm font-medium text-gray-700">
                            {formatTime(slot.start_time)} - {formatTime(slot.end_time)}
                          </span>
                        </div>

                        {/* Status */}
                        <div className="mt-1.5 flex items-center justify-between">
                          <span className="text-sm text-gray-500">
                            {slot.total_bookings}/3 booked
                          </span>
                          <span
                            className={`
                              text-xs px-1.5 py-0.5 rounded-full
                              ${
                                isAvailable
                                  ? "text-primary bg-primary/10"
                                  : isFull
                                  ? "text-gray-500 bg-gray-100"
                                  : "text-gray-500 bg-gray-100"
                              }
                            `}
                          >
                            {isAvailable ? "Available" : isFull ? "Full" : "Pending"}
                          </span>
                        </div>

                        {/* Remaining spots */}
                        {isAvailable && slot.total_bookings < 3 && (
                          <div className="mt-1 text-xs text-primary">
                            {3 - slot.total_bookings} left
                          </div>
                        )}
                      </button>
                    );
                  })
                ) : (
                  <div className="col-span-2 flex flex-col items-center justify-center py-8">
                    <Clock3 className="w-8 h-8 text-gray-300 mb-2" />
                    <p className="text-sm font-medium text-gray-500">
                      No {selectedPeriod} Slots
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      Try another time
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Slots;