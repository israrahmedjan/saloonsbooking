"use client";

import { supabase } from "@/app/lib/supabaseClient";
import React, { useEffect, useMemo, useState } from "react";

import {
  format,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  addWeeks,
  subWeeks,
  isToday,
} from "date-fns";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock,
  CircleX,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { availabilityType } from "@/app/lib/types";
import Slots from "./slots";
import SaloonServices from "./SaloonServices";
import { Salon, Service } from "@/app/lib/types";

function CalendarContant({ salons, salon_id, service_id }: { salons: Salon; salon_id: number; service_id: number }) {
  const [availability, setAvailability] = useState<availabilityType[]>([]);
  const [availableSlots, setAvailableSlots] = useState<availabilityType | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedDays, setExpandedDays] = useState<string[]>([]);

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const weekStart = useMemo(
    () => startOfWeek(currentDate, { weekStartsOn: 0 }),
    [currentDate]
  );

  const weekEnd = useMemo(
    () => endOfWeek(currentDate, { weekStartsOn: 0 }),
    [currentDate]
  );

  const days = useMemo(
    () =>
      eachDayOfInterval({
        start: weekStart,
        end: weekEnd,
      }),
    [weekStart, weekEnd]
  );

  const nextWeek = () => {
    setCurrentDate(addWeeks(currentDate, 1));
  };

  const previousWeek = () => {
    setCurrentDate(subWeeks(currentDate, 1));
  };

  useEffect(() => {
    async function getSalonAvailability() {
      try {
        setLoading(true);
        const start_date = format(weekStart, "yyyy-MM-dd");
        const end_date = format(weekEnd, "yyyy-MM-dd");

        const { data, error } = await supabase
          .rpc("get_salon_availability", {
            start_date,
            end_date,
            p_salon_id: salon_id,
          });

        if (error) throw error;

        const availabilityData = data ?? [];
        setAvailability(availabilityData);

        const currentDaySlot =
          availabilityData.find(
            (item: availabilityType) =>
              item.booking_date === format(currentDate, "yyyy-MM-dd")
          ) ?? null;

        if (currentDaySlot) {
          setAvailableSlots({ ...currentDaySlot, salon_id: salon_id, service_id: service_id });
        }
      } catch (error: unknown) {
        console.log(
          "Supabase Error:",
          error instanceof Error ? error.message : "Something went wrong"
        );
      } finally {
        setLoading(false);
      }
    }

    getSalonAvailability();
  }, [salon_id, service_id, currentDate, weekStart, weekEnd]);

  const showAvailableSlots = (slots: availabilityType) => {
    setAvailableSlots({
      ...slots,
      salon_id,
      service_id,
    });
  };

  const toggleDayExpand = (date: string) => {
    setExpandedDays(prev =>
      prev.includes(date)
        ? prev.filter(d => d !== date)
        : [...prev, date]
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-primary text-sm">Loading...</div>
      </div>
    );
  }

  return (
    <>
      {/* Desktop View - Grid */}
      <div className="hidden lg:grid container mx-auto grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column */}
        <div className="lg:col-span-8">
          <div className="bg-white rounded-lg border border-gray-100 p-5">
            {/* Header */}
            <div className="flex items-center justify-between mb-5">
              <button
                onClick={previousWeek}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-100 rounded hover:border-primary/30 hover:text-primary transition"
              >
                <ChevronLeft size={14} />
                Prev
              </button>

              <div className="text-center">
                <div className="flex items-center justify-center gap-2">
                  <CalendarDays size={16} className="text-primary" />
                  <h3 className="text-lg font-medium">
                    {format(weekStart, "MMMM yyyy")}
                  </h3>
                </div>
                <p className="text-sm mt-0.5">
                  {format(weekStart, "dd MMM")} - {format(weekEnd, "dd MMM yyyy")}
                </p>
              </div>

              <button
                onClick={nextWeek}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-100 rounded hover:border-primary/30 hover:text-primary transition"
              >
                Next
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Day Headers */}
            <div className="grid grid-cols-7 gap-1.5 mb-1.5">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div
                  key={day}
                  className="text-center font-medium py-1.5"
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1.5">
              {days.map((day) => {
                const dayData = availability.find(
                  (item) => item.booking_date === format(day, "yyyy-MM-dd")
                );

                const isSelected = dayData && availableSlots?.booking_date === format(day, "yyyy-MM-dd");

                return (
                  <div
                    key={day.toString()}
                    onClick={() =>
                      dayData && !dayData.is_closed && showAvailableSlots(dayData)
                    }
                    className={`
                      min-h-[100px] rounded border p-2.5 transition
                      ${
                        dayData && !dayData.is_closed
                          ? "cursor-pointer hover:border-primary/40"
                          : "cursor-default"
                      }
                      ${
                        isToday(day)
                          ? "border-secondary/20 bg-secondary/15"
                          : isSelected
                          ? "border-secondary/20 bg-secondary/15"
                          : "border-primary/10"
                      }
                      ${dayData?.is_closed ? "bg-gray-50/50" : ""}
                    `}
                  >
                    <div className={`font-medium mb-2 ${isToday(day) ? "text-primary" : "text-primary/30"}`}>
                      {format(day, "d")}
                    </div>

                    {dayData && (
                      dayData.is_closed ? (
                        <div className="flex items-center gap-1 text-sm text-primary font-semibold">
                          <CircleX size={12} />
                          Closed
                        </div>
                      ) : (
                        <div className="space-y-1 text-primary/50">
                          <div className="flex items-center gap-1 text-sm">
                            <Clock size={12} className="text-primary flex-shrink-0" />
                            <span>{dayData.open_time}</span>
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            <Clock size={12} className="text-primary flex-shrink-0" />
                            <span>{dayData.close_time}</span>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Slots Section */}
          {availableSlots && (
            <div className="mt-4">
              <Slots slots={availableSlots} />
            </div>
          )}
        </div>

        {/* Right Column */}
        <aside className="lg:col-span-4">
          {salons && <SaloonServices salons={salons} service_id={service_id} />}
        </aside>
      </div>

      {/* Mobile View - List */}
      <div className="lg:hidden container mx-auto px-4">
        <div className="bg-white rounded-lg border border-gray-100 p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={previousWeek}
              className="flex items-center gap-1 px-3 py-2 border border-gray-100 rounded-lg text-sm hover:border-primary/30 hover:text-primary transition"
            >
              <ChevronLeft size={16} />
              <span>Prev</span>
            </button>

            <div className="text-center">
              <div className="flex items-center justify-center gap-1.5">
                <CalendarDays size={16} className="text-primary" />
                <h3 className="text-sm font-medium">
                  {format(weekStart, "MMM yyyy")}
                </h3>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                {format(weekStart, "dd")} - {format(weekEnd, "dd MMM")}
              </p>
            </div>

            <button
              onClick={nextWeek}
              className="flex items-center gap-1 px-3 py-2 border border-gray-100 rounded-lg text-sm hover:border-primary/30 hover:text-primary transition"
            >
              <span>Next</span>
              <ChevronRight size={16} />
            </button>
          </div>

          {/* List View Days */}
          <div className="space-y-2">
            {days.map((day) => {
              const dayData = availability.find(
                (item) => item.booking_date === format(day, "yyyy-MM-dd")
              );

              const isSelected = dayData && availableSlots?.booking_date === format(day, "yyyy-MM-dd");
              const isExpanded = expandedDays.includes(format(day, "yyyy-MM-dd"));
              const hasSlots = dayData && !dayData.is_closed;

              return (
                <div
                  key={day.toString()}
                  className={`
                    rounded-lg border transition-all overflow-hidden
                    ${isSelected ? "border-primary bg-primary/5" : "border-gray-100"}
                    ${hasSlots ? "cursor-pointer" : "cursor-default"}
                  `}
                >
                  {/* Day Header */}
                  <div
                    onClick={() => {
                      if (hasSlots) {
                        toggleDayExpand(format(day, "yyyy-MM-dd"));
                        showAvailableSlots(dayData);
                      }
                    }}
                    className="flex items-center justify-between p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`
                        w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold
                        ${isToday(day) ? "bg-primary text-white" : "bg-gray-50 text-gray-700"}
                      `}>
                        {format(day, "d")}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-700">
                          {format(day, "EEEE")}
                        </div>
                        {dayData && !dayData.is_closed && (
                          <div className="text-xs text-gray-400">
                            {dayData.open_time} - {dayData.close_time}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {dayData && (
                        dayData.is_closed ? (
                          <span className="text-xs text-gray-400 bg-gray-50 px-2 py-1 rounded-full">
                            Closed
                          </span>
                        ) : (
                          <span className="text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">
                            Available
                          </span>
                        )
                      )}
                      {hasSlots && (
                        <div className="text-gray-400">
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && dayData && !dayData.is_closed && (
                    <div className="border-t border-gray-100 p-3 bg-gray-50/50">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock size={14} className="text-primary" />
                          <span>Open: <strong>{dayData.open_time}</strong></span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock size={14} className="text-primary" />
                          <span>Close: <strong>{dayData.close_time}</strong></span>
                        </div>
                        {/* {dayData.slot_duration && (
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <span className="text-xs bg-gray-100 px-2 py-0.5 rounded">
                              {dayData.slot_duration} min slots
                            </span>
                          </div>
                        )} */}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Slots Section */}
        {availableSlots && (
          <div className="mt-4">
            <Slots slots={availableSlots} />
          </div>
        )}

        {/* Services Section */}
        <div className="mt-4">
          {salons && <SaloonServices salons={salons} service_id={service_id} />}
        </div>
      </div>
    </>
  );
}

export default CalendarContant;