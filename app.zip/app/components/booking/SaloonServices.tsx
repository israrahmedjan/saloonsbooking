'use client'
import React from 'react'
import { Salon,Service } from '@/app/lib/types';
import Link from 'next/link';
import { Sparkles } from "lucide-react";
function SaloonServices({salons,service_id}:{salons:Salon,service_id:number}) {
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;

  return (
    <div>
  {/* {JSON.stringify(service_id,null,2)} */}
          <div className="space-y-3">
          {/* ccc   {baseUrl} */}
         <h4 className="flex items-center gap-2 border-b border-secondary/20 pb-2 text-lg font-semibold">
  <Sparkles className="h-5 w-5 text-secondary" />
  Explore More Services
</h4>
  { salons.services?.map((service:Service) => (
   <div
  key={service.id}
  className={`rounded-xl border border-secondary/20 p-4 ${
    service_id === service.id
      ? "bg-secondary/10 text-white border-secondary"
      : "bg-white"
  } hover:border-secondary transition`}
> <Link href={`${baseUrl}/salons/${salons.slug}/services/${service.slug}`}>
   <h3 className="text-lg text-primary">
       
        {service.name}
       
      </h3> 

      <div className="mt-2 flex items-center justify-between text-sm">
        <span>{service.duration}</span>
        <span className="font-medium text-secondary">
          {service.price}
        </span>
      </div>
      </Link>
    </div>
  ))}
</div>  
    </div>
  )
}

export default SaloonServices