import { Calendar, Clock3, DollarSign } from "lucide-react";

interface ServiceHeaderProps {
  service: {
    name?: string;
    price?: number | string;
    duration?: number | string;

  };
}

export default function ServiceHeader({ service }: any) {

    console.log('cekjrer0',service)
   
  return (
    <div className="container py-3 mb-6 mt-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
 
      <h4 className="flex items-center gap-2">
        <Calendar className="h-8 w-8 text-secondary" />
        Our Reliable Service ({service?.name})
      </h4>

      <div className="flex items-center gap-4 text-sm text-gray-600">
        <div className="flex items-center gap-1 rounded-full bg-green-50 px-3 py-1">
          <DollarSign className="h-4 w-4 text-green-600" />
          <span className="font-medium">${service?.price}</span>
        </div>

        <div className="flex items-center gap-1 rounded-full bg-blue-50 px-3 py-1">
          <Clock3 className="h-4 w-4 text-blue-600" />
          <span className="font-medium">{service?.duration} min</span>
        </div>
      </div>
    </div>
  );
}