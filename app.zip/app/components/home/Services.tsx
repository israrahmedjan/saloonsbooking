"use client";

import Image from "next/image";
import Link from "next/link";
import { Clock, Star } from "lucide-react";

const services = [
  {
    id: 1,
    title: "Hair Styling",
    image: "/images/fasher.png",
    rating: 4.9,
    duration: "60 Min",
  },
  {
    id: 2,
    title: "Bridal Makeup",
    image: "/images/fasher.png",
    rating: 5.0,
    duration: "120 Min",
  },
  {
    id: 3,
    title: "Facial Treatment",
    image: "/images/fasher.png",
    rating: 4.8,
    duration: "45 Min",
  },
  {
    id: 4,
    title: "Nail Care",
   image: "/images/fasher.png",
    rating: 4.7,
    duration: "40 Min",
  },
];

export default function Services() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h4 className=" text-secondary uppercase font-[500]">
            What I Offer
          </h4>

          <h2 className="mt-3">
            Services Crafted with Love
          </h2>

          <p className="mt-4 text-lg mb-6">
            Every service I offer comes from years of passion and
            experience. I use only the best products and take my time to
            ensure you leave feeling amazing.
          </p>
          <h3 className="text-secondary">Bridal Makeup</h3>
          <p className="mt-2">Complete bridal transformation for your special day</p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {services.map((service) => (
            <div key={service.id} className="overflow-hidden rounded-lg shadow-sm transition-transform hover:scale-105">
              {/* Image */}
              <div className="relative h-64">
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  className="object-cover"
                />
              </div>

              {/* Content */}
              <div className="space-y-4 p-5">
                <h4 className="text-lg text-primary">{service.title}</h4>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star size={16} />
                    <span>{service.rating}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{service.duration}</span>
                  </div>
                </div>

                <Link
                  href="/appointment"
                  className="block text-center btn-type-2 font-semibold"
                >
                  Book Now
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>



      {/* Party Events */}
          <div className="container mx-auto px-4 mt-20">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-2xl text-center">
  
         
          <h3 className="text-secondary">Party & Event Makeup</h3>
          <p className="mt-2">Complete bridal transformation for your special day</p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {services.map((service) => (
            <div key={service.id} className="overflow-hidden rounded-lg shadow-sm transition-transform hover:scale-105">
              {/* Image */}
              <div className="relative h-64">
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  className="object-cover"
                />
              </div>

              {/* Content */}
              <div className="space-y-4 p-5">
                <h4 className="text-lg text-primary">{service.title}</h4>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star size={16} />
                    <span>{service.rating}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{service.duration}</span>
                  </div>
                </div>

                <Link
                  href="/appointment"
                  className="block text-center btn-type-2 font-semibold"
                >
                  Book Now
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>



           {/* Hair Style */}
          <div className="container mx-auto px-4 mt-20">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-2xl text-center">
  
         
          <h3 className="text-secondary">Hair Styling</h3>
          <p className="mt-2">Complete bridal transformation for your special day</p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {services.map((service) => (
            <div key={service.id} className="overflow-hidden rounded-lg shadow-sm transition-transform hover:scale-105">
              {/* Image */}
              <div className="relative h-64">
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  className="object-cover"
                />
              </div>

              {/* Content */}
              <div className="space-y-4 p-5">
                <h4 className="text-lg text-primary">{service.title}</h4>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star size={16} />
                    <span>{service.rating}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{service.duration}</span>
                  </div>
                </div>

                <Link
                  href="/appointment"
                  className="block text-center btn-type-2 font-semibold"
                >
                  Book Now
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}