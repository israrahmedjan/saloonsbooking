"use client";

import Link from "next/link";
import { Mail, Phone, Clock } from "lucide-react";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaYoutube,
} from "react-icons/fa6";

function Topmenu() {
  return (
    <div className="bg-secondary/10 text-sm">
      <div className="container mx-auto flex h-10 items-center justify-between px-4">
        {/* Left */}
        <div className="flex items-center gap-3 md:gap-5">
          {/* Time - Desktop Only */}
          <div className="hidden lg:flex items-center gap-2">
            <Clock size={15} className="text-secondary" />
            <span>Mon - Fri: 09:00 AM - 06:00 PM</span>
          </div>

          {/* Phone - Always Visible */}
          <Link
            href="tel:+923001234567"
            className="flex items-center gap-2 hover:text-secondary transition-colors"
          >
            <Phone size={15} className="text-secondary" />
            <span className="hidden sm:inline">+92 300 1234567</span>
          </Link>

          {/* Email - Tablet & Desktop */}
          <Link
            href="mailto:info@example.com"
            className="hidden md:flex items-center gap-2 hover:text-secondary transition-colors"
          >
            <Mail size={15} className="text-secondary" />
            <span>info@example.com</span>
          </Link>
        </div>

        {/* Right */}
        <div className="flex items-center gap-3">
          <Link
            href="#"
            aria-label="Facebook"
            className="text-secondary hover:text-primary transition-colors"
          >
            <FaFacebookF size={15} />
          </Link>

          <Link
            href="#"
            aria-label="Instagram"
            className="text-secondary hover:text-primary transition-colors"
          >
            <FaInstagram size={15} />
          </Link>

          <Link
            href="#"
            aria-label="LinkedIn"
            className="text-secondary hover:text-primary transition-colors"
          >
            <FaLinkedinIn size={15} />
          </Link>

          <Link
            href="#"
            aria-label="YouTube"
            className="text-secondary hover:text-primary transition-colors"
          >
            <FaYoutube size={15} />
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Topmenu;