"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu, X, ChevronDown, Calendar } from "lucide-react";
import Topmenu from "./Topmenu";
import { Caveat } from "next/font/google";

const caveat = Caveat({
  subsets: ["latin"],
  weight: ["400", "700"],
});
const menus = [
  {
    name: "Home",
    href: "/",
  },
  {
    name: "Services",
    href: "/services",
    dropdown: true,
    subMenus: [
      { name: "Hair Styling", href: "/services/hair-styling" },
      { name: "Makeup", href: "/services/makeup" },
      { name: "Nail Care", href: "/services/nail-care" },
      { name: "Skincare", href: "/services/skincare" },
      { name: "Massage Therapy", href: "/services/massage-therapy" },
      { name: "Bridal Services", href: "/services/bridal" },
    ],
  },
  {
    name: "Salons",
    href: "/salons",
  },
  {
    name: "About",
    href: "/about",
  },
  {
    name: "Contact",
    href: "/contact",
  },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);


  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40); // TopMenu ki height
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>

      {/* Top menu */}
      <Topmenu />
      {/* Top menu End */}
      <header
        className={`fixed left-0 z-50 w-full bg-white shadow-sm transition-all duration-300 ${scrolled ? "top-0" : "top-10"
          }`}
      >

        <div className="container mx-auto flex h-20 items-center justify-between px-4 ">
          {/* Logo */}
          <Link
            href="/"
            className={`${caveat.className} text-5xl font-[700]  text-secondary`}
          >
            <span className="text-primary">
              Our
            </span>
            Salon
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center gap-6">
            {menus.map((menu) => (
              <div key={menu.href} className="relative">
                {menu.dropdown ? (
                  <div
                    className="relative"
                    onMouseEnter={() => setDropdownOpen(true)}
                    onMouseLeave={() => setDropdownOpen(false)}
                  >
                    <button
                      className="text-lg transition-colors hover:text-secondary  flex items-center gap-1"
                    >
                      {menu.name}
                      <ChevronDown size={16} />
                    </button>
                    {dropdownOpen && (
                      <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg py-2 z-50">
                        {menu.subMenus.map((subMenu) => (
                          <Link
                            key={subMenu.href}
                            href={subMenu.href}
                            className="block px-4 py-2 text-md hover:bg-secondary/10   transition-colors"
                          >
                            {subMenu.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    href={menu.href}
                    className="text-lg transition-colors duration-300 hover:text-secondary underline-offset-4 hover:underline"
                  >
                    {menu.name}
                  </Link>
                )}
              </div>
            ))}

            {/* Desktop Appointment Button */}
            <Link
              href="/salons/royal-beauty-salon/services/hair-cut"
              className="btn-type-1"
            >
              <Calendar size={18} />
              Book Appointmentd
            </Link>
          </nav>

          {/* Mobile Button */}
          <button
            onClick={() => setOpen(!open)}
            className="rounded-md p-2 md:hidden"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {open && (
          <div className="border-t md:hidden">
            <nav className="flex flex-col">
              {menus.map((menu) => (
                <div key={menu.href} className="w-full">
                  {menu.dropdown ? (
                    <div className="w-full">
                      <button
                        onClick={() => setDropdownOpen(!dropdownOpen)}
                        className="flex items-center justify-between w-full px-4 py-3 hover:bg-muted"
                      >
                        <span>{menu.name}</span>
                        <ChevronDown
                          size={16}
                          className={`transition-transform ${dropdownOpen ? "rotate-180" : ""
                            }`}
                        />
                      </button>
                      {dropdownOpen && (
                        <div className="bg-muted/30">
                          {menu.subMenus.map((subMenu) => (
                            <Link
                              key={subMenu.href}
                              href={subMenu.href}
                              onClick={() => {
                                setOpen(false);
                                setDropdownOpen(false);
                              }}
                              className="block pl-8 pr-4 py-2 text-sm hover:bg-muted"
                            >
                              {subMenu.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link
                      href={menu.href}
                      onClick={() => setOpen(false)}
                      className="block w-full px-4 py-3 hover:bg-muted"
                    >
                      {menu.name}
                    </Link>
                  )}
                </div>
              ))}

              {/* Mobile Appointment Button */}
              <div className="w-full px-4 py-2">
                <Link
                href="/salons/royal-beauty-salon/services/hair-cut"
                onClick={() => setOpen(false)}
                className="flex items-center justify-center gap-2 w-full bg-primary text-white px-6 py-3 rounded-md text-sm font-medium hover:bg-primary/90 transition-all"
              >
                <Calendar size={18} />
                Book Appointment
              </Link>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>

  );
}